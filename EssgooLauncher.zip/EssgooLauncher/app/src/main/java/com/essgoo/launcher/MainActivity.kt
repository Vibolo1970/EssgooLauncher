package com.essgoo.launcher

import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : Activity() {

    // Paquetes habituales en radios ESSGOO / ZLINK. Edita según tu unidad.
    private val carPlayPkgs = listOf("com.zjinnova.zlink", "com.zlink.carplay", "com.carlink.carplay")
    private val androidAutoPkgs = listOf("com.zjinnova.zlink", "com.google.android.projection.gearhead")
    private val cameraPkgs = listOf("com.syu.camera360", "com.android.camera2")
    private val settingsPkgs = listOf("com.android.settings")

    private lateinit var clock: TextView
    private lateinit var date: TextView
    private val handler = android.os.Handler(mainLooper)
    private val tick = object : Runnable {
        override fun run() {
            val now = Date()
            clock.text = SimpleDateFormat("HH:mm", Locale.getDefault()).format(now)
            date.text = SimpleDateFormat("EEEE d MMM", Locale.getDefault()).format(now)
            handler.postDelayed(this, 10_000)
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun launch(pkgs: List<String>): Boolean {
        for (p in pkgs) {
            packageManager.getLaunchIntentForPackage(p)?.let { startActivity(it); return true }
        }
        Toast.makeText(this, "App no encontrada", Toast.LENGTH_SHORT).show()
        return false
    }

    private fun tile(title: String, color: Int, onClick: () -> Unit): TextView =
        TextView(this).apply {
            text = title
            textSize = 24f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            background = GradientDrawable().apply { cornerRadius = dp(24).toFloat(); setColor(color) }
            setOnClickListener { onClick() }
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f)
                .apply { setMargins(dp(6), dp(6), dp(6), dp(6)) }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#0E1116"))
            setPadding(dp(16), dp(12), dp(16), dp(12))
        }

        // Cabecera: hora y fecha
        val header = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        clock = TextView(this).apply { textSize = 44f; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD }
        date = TextView(this).apply { textSize = 18f; setTextColor(Color.parseColor("#9AA4B2")); setPadding(dp(16), 0, 0, 0) }
        header.addView(clock); header.addView(date)
        root.addView(header, LinearLayout.LayoutParams(-1, -2))

        // Fila de accesos principales
        val main = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        main.addView(tile("CarPlay", Color.parseColor("#1C8EF9")) { launch(carPlayPkgs) })
        main.addView(tile("Android Auto", Color.parseColor("#2E9E5B")) { launch(androidAutoPkgs) })
        main.addView(tile("Cámara", Color.parseColor("#E8833A")) { launch(cameraPkgs) })
        main.addView(tile("Ajustes", Color.parseColor("#6B7280")) { launch(settingsPkgs) })
        root.addView(main, LinearLayout.LayoutParams(-1, 0, 1.2f))

        // Cajón de apps
        val grid = GridView(this).apply {
            numColumns = 6
            verticalSpacing = dp(8)
            horizontalSpacing = dp(8)
            adapter = AppsAdapter()
            setOnItemClickListener { _, _, pos, _ ->
                (adapter as AppsAdapter).getItem(pos).let { startActivity(it.intent) }
            }
        }
        root.addView(grid, LinearLayout.LayoutParams(-1, 0, 2f).apply { topMargin = dp(8) })

        setContentView(root)
    }

    override fun onResume() { super.onResume(); handler.post(tick) }
    override fun onPause() { super.onPause(); handler.removeCallbacks(tick) }
    override fun onBackPressed() { /* launcher: no salir */ }

    private data class AppEntry(val label: String, val icon: android.graphics.drawable.Drawable, val intent: Intent)

    private inner class AppsAdapter : BaseAdapter() {
        private val apps: List<AppEntry> = run {
            val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            packageManager.queryIntentActivities(q, PackageManager.MATCH_ALL)
                .filter { it.activityInfo.packageName != packageName }
                .map {
                    AppEntry(
                        it.loadLabel(packageManager).toString(),
                        it.loadIcon(packageManager),
                        packageManager.getLaunchIntentForPackage(it.activityInfo.packageName) ?: Intent()
                    )
                }
                .sortedBy { it.label.lowercase() }
        }
        override fun getCount() = apps.size
        override fun getItem(p: Int) = apps[p]
        override fun getItemId(p: Int) = p.toLong()
        override fun getView(p: Int, v: View?, parent: ViewGroup): View {
            val a = apps[p]
            val cell = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                setPadding(dp(4), dp(8), dp(4), dp(8))
            }
            cell.addView(ImageView(this@MainActivity).apply { setImageDrawable(a.icon) }, LinearLayout.LayoutParams(dp(56), dp(56)))
            cell.addView(TextView(this@MainActivity).apply {
                text = a.label; textSize = 14f; maxLines = 1
                setTextColor(Color.WHITE); gravity = Gravity.CENTER
                ellipsize = android.text.TextUtils.TruncateAt.END
            })
            return cell
        }
    }
}
